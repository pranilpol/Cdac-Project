import React from 'react'

const Footer = () => {
    return (
        <>
        <footer className="bg-light text-center footer">
            <p>&copy; 2023 Medicare. All Rights Reserved | Terms and Condition.</p>
        </footer>
        </>
    )
}

export default Footer;