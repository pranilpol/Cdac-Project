import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import web from "../src/images/img4.gif";
import Common from "./Common";

import Navbar from "./Navbar";

import './App.css'
import 'react-chatbot-kit/build/main.css'
import Footer from "./Footer";


const Home = () => {
    
    return (
        <>
            <Navbar />
            <Common name='Get Your Appointment Booked on '
                imgsrc={web}
                visit="/service"
                btname="Get Started" />
        
            
            
            <Footer/>
        </>

    );
};

export default Home;